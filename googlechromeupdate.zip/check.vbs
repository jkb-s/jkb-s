
' Create a WMI object
Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")

' Execute a WMI query to get the operating system information
Set colOperatingSystems = objWMIService.ExecQuery("Select * from Win32_OperatingSystem")

' Loop through the collection and display the information
For Each objOperatingSystem in colOperatingSystems
    WScript.Echo "Caption: " & objOperatingSystem.Caption
    WScript.Echo "Version: " & objOperatingSystem.Version
    WScript.Echo "Manufacturer: " & objOperatingSystem.Manufacturer
    WScript.Echo "Build Number: " & objOperatingSystem.BuildNumber
    WScript.Echo "OS Architecture: " & objOperatingSystem.OSArchitecture
Next

